package org.ump.sms.ejb;

import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.jms.JMSContext;
import jakarta.jms.Queue;
import jakarta.annotation.Resource;

@Stateless
public class EnrollmentService {

    @Resource(lookup="jms/gradeQueue")
    private Queue gradeQueue;

    @Inject
    private JMSContext jms;

    public void enrollAndNotify(long studentId, long courseId) {
        // TODO: persist Enrollment entity and send JMS message
        String payload = "ENROLL:" + studentId + ":" + courseId;
        jms.createProducer().send(gradeQueue, payload);
    }
}
