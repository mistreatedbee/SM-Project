# Jakarta EE School Management System (SMS) — Starter Workspace

This archive contains a Maven **multi-module** starter workspace implementing the labs from
*DICT312_Modular_Tutorial_Labs_with_Rubrics.pdf* (University of Mpumalanga). It's prepared to
import into **NetBeans** and deploy to **GlassFish 7+**. It includes SQL schema, code templates
for REST, JSF, JPA, EJB, and admin commands.

## What is included
- `sql/schema.sql` — MySQL schema (creates DB, tables, seeds roles/admin user placeholder).
- `asadmin_commands.txt` — GlassFish `asadmin` commands to create JDBC & JMS resources.
- `sms-parent/` — Maven parent project.
- `sms-model/` — Shared model module (JPA entity).
- `sms-rest/` — REST module (JAX-RS): `/api/students`.
- `sms-jsf/` — JSF admin UI module (index.xhtml + backing bean).
- `sms-ejb/` — EJB module with a sample EnrollmentService.
- Basic `pom.xml` files and minimal Java sources.

> NOTE: This is a starter scaffold. Each lab from the tutorial should be completed/extended
> by implementing business logic, wiring persistence, refining security, and adding tests.

---

## Quick setup (Windows / macOS / Linux)

### Prerequisites
1. **JDK 17+** installed and `JAVA_HOME` set.
2. **NetBeans (latest)** installed.
3. **GlassFish 7+** installed.
4. **MySQL 8.x** installed and running.
5. Optional: `mvn` (Maven) on PATH — NetBeans manages Maven but CLI can help.

### MySQL — create schema & seed
1. Open MySQL CLI or a GUI (MySQL Workbench) and run `sql/schema.sql` included in this repo.
   ```sh
   mysql -u root -p < sql/schema.sql
   ```
   The script creates database `sms`, tables, and role seeds. It includes a placeholder
   for an admin user; you must replace the `{PBKDF2}...hash...` placeholder with a real PBKDF2 hash
   (or temporarily use a plain password for testing and then change it).

### GlassFish — copy Connector/J
1. Download MySQL Connector/J (mysql-connector-j-8.x.jar).
2. Copy the JAR to:
   ```
   ${GLASSFISH_HOME}/glassfish/domains/domain1/lib/
   ```
3. Restart GlassFish.

### GlassFish — create JDBC, JMS resources
Use the commands in `asadmin_commands.txt` or run them via the Admin Console (`http://localhost:4848`).

Example (adjust user/password/URL):
```sh
asadmin start-domain domain1

asadmin create-jdbc-connection-pool   --restype javax.sql.DataSource   --driverclassname com.mysql.cj.jdbc.Driver   --property user=sms_user:password=yourpassword:URL=jdbc\:mysql\://localhost\:3306/sms?serverTimezone\=Africa/Johannesburg\&useSSL\=false mysqlPool

asadmin create-jdbc-resource --connectionpoolid mysqlPool jdbc/smsDS

asadmin create-jms-resource --restype jakarta.jms.ConnectionFactory jms/smsCF

asadmin create-jms-resource --restype jakarta.jms.Queue --property Name=gradeQueue jms/gradeQueue
```

### Import into NetBeans
1. Open NetBeans → File → Open Project.
2. Navigate to `sms-parent` in this workspace and open it. NetBeans will detect modules.
3. Build the parent project (right-click → Build).
4. Deploy modules (right-click each web module → Deploy) or set up an EAR.

---

## How to run the example REST endpoint (after deploy)
- `GET http://localhost:8080/sms-rest/api/students` — returns a sample JSON list (stub).
- `POST http://localhost:8080/sms-rest/api/students` — create student (stub).

JSF UI (after deploying `sms-jsf` to GlassFish):
- `http://localhost:8080/sms-jsf/index.xhtml`

---

## Files of interest
- `sql/schema.sql` — MySQL schema and seeds.
- `sms-model/src/main/java/org/ump/sms/model/Student.java` — JPA entity stub.
- `sms-rest/src/main/java/org/ump/sms/rest/StudentResource.java` — REST resource stub.
- `sms-jsf/src/main/webapp/index.xhtml` — JSF page.
- `asadmin_commands.txt` — helpful admin commands.

---

## Next steps & lab mapping
- **Lab 0**: Run the SQL and create GlassFish resources (JDBC/JMS). Take screenshots.
- **Lab 1–3**: Implement CDI producers, REST endpoints, JSON-B formats.
- **Lab 4–6**: Split services, implement JPA, wire `persistence.xml` to `jdbc/smsDS`.
- **Lab 7–11**: Add WebSocket, Security, Servlets for CSV upload, EJBs, and JMS/MDB.
- **Lab 12–13**: Add Bean Validation and SOAP endpoint.

---

## Support
If you want, I can:
- Generate complete JPA repositories and DTOs.
- Implement full Jakarta Security (DB identity store + seed hashed password).
- Expand each lab into working, fully implemented code.
Tell me which labs you want prioritized and I will expand them next.

--- End of README
