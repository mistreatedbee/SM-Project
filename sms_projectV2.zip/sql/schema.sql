CREATE DATABASE IF NOT EXISTS sms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sms;

CREATE TABLE roles (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(30) UNIQUE NOT NULL
);

CREATE TABLE users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(120) UNIQUE,
  enabled BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE user_roles (
  user_id BIGINT NOT NULL,
  role_id BIGINT NOT NULL,
  PRIMARY KEY(user_id, role_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE lecturers (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  staff_no VARCHAR(20) UNIQUE NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(120) UNIQUE
);

CREATE TABLE students (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  student_no VARCHAR(20) UNIQUE NOT NULL,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(120) UNIQUE,
  registered_on DATE NOT NULL
);

CREATE TABLE courses (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  code VARCHAR(10) UNIQUE NOT NULL,
  title VARCHAR(120) NOT NULL,
  credits INT NOT NULL,
  lecturer_id BIGINT,
  FOREIGN KEY (lecturer_id) REFERENCES lecturers(id)
);

CREATE TABLE enrollments (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  student_id BIGINT NOT NULL,
  course_id BIGINT NOT NULL,
  enrolled_on DATE NOT NULL,
  UNIQUE(student_id, course_id),
  FOREIGN KEY (student_id) REFERENCES students(id),
  FOREIGN KEY (course_id) REFERENCES courses(id)
);

CREATE TABLE grades (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  enrollment_id BIGINT NOT NULL,
  score DECIMAL(5,2) NOT NULL,
  graded_on TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (enrollment_id) REFERENCES enrollments(id)
);

INSERT INTO roles(name) VALUES ('ADMIN'), ('LECTURER'), ('STUDENT');

-- Seed admin user placeholder: replace {PBKDF2}...hash... with a real PBKDF2 password hash
INSERT INTO users(username,password,email,enabled) VALUES (
  'admin', '{PBKDF2}...hash...', 'admin@ump.ac.za', TRUE
);

-- Map admin role (after user exists, or run manually to map ids)
-- INSERT INTO user_roles(user_id, role_id) SELECT u.id, r.id FROM users u, roles r WHERE u.username='admin' AND r.name='ADMIN';
