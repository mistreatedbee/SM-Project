package org.ump.sms.jsf;

import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;
import java.io.Serializable;

@Named
@RequestScoped
public class CourseView implements Serializable {
    public String getMessage() {
        return "Welcome to SMS Admin (placeholder)";
    }
}
