package org.ump.sms.rest;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.ump.sms.model.Student;
import java.util.List;
import java.util.ArrayList;

@Path("/students")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class StudentResource {

    @GET
    public List<Student> list() {
        // TODO: wire JPA to return real students
        var s = new Student();
        s.setId(1L);
        s.setStudentNo("S0001");
        s.setFirstName("Test");
        s.setLastName("Student");
        s.setEmail("test.student@example.com");
        return List.of(s);
    }

    @POST
    public Response create(Student dto) {
        // TODO: validate & persist via JPA
        return Response.status(Response.Status.CREATED).entity(dto).build();
    }
}
