package za.ac.ump.sms.lab03.api;
import jakarta.ws.rs.core.Application;
import jakarta.ws.rs.ApplicationPath;
@ApplicationPath("/api")
public class JsonApp extends Application {}
