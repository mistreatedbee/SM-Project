package za.ac.ump.sms.lab03.api;
import jakarta.json.Json;
import jakarta.json.JsonObject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
@Path("/json")
@Produces(MediaType.APPLICATION_JSON)
public class JsonDemoResource {
  @GET @Path("/diagnostics")
  public JsonObject diagnostics(){
    return Json.createObjectBuilder()
      .add("app","lab03-json")
      .add("time", java.time.Instant.now().toString())
      .build();
  }
}
