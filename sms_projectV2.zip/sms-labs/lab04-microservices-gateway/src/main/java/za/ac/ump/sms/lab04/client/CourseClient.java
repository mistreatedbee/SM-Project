package za.ac.ump.sms.lab04.client;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import java.util.List;
@ApplicationScoped
public class CourseClient {
  private final Client client = ClientBuilder.newClient();
  public List<String> findAllCodes(){
    return client.target("http://localhost:8080/course-service/api/courses/codes")
      .request(MediaType.APPLICATION_JSON)
      .get(new GenericType<List<String>>(){});
  }
}
