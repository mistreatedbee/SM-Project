package za.ac.ump.sms.lab04.api;
import jakarta.ws.rs.core.Application;
import jakarta.ws.rs.ApplicationPath;
@ApplicationPath("/api")
public class GatewayApp extends Application {}
