package za.ac.ump.sms.lab08.security;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.security.enterprise.authentication.mechanism.http.FormAuthenticationMechanismDefinition;
import jakarta.security.enterprise.identitystore.DatabaseIdentityStoreDefinition;
import jakarta.security.enterprise.identitystore.LdapIdentityStoreDefinition;
import jakarta.security.enterprise.identitystore.Pbkdf2PasswordHash;

@ApplicationScoped
@DatabaseIdentityStoreDefinition(
  dataSourceLookup="jdbc/smsDS",
  callerQuery="SELECT password FROM users WHERE username = ? AND enabled = TRUE",
  groupsQuery="SELECT r.name FROM user_roles ur JOIN users u ON ur.user_id=u.id JOIN roles r ON ur.role_id=r.id WHERE u.username = ?",
  hashAlgorithm = Pbkdf2PasswordHash.class,
  priority=10
)
@LdapIdentityStoreDefinition(
  url="ldap://localhost:389",
  bindDn="cn=admin,dc=ump,dc=ac,dc=za",
  bindDnPassword="admin_password",
  callerBaseDn="ou=people,dc=ump,dc=ac,dc=za",
  groupSearchBase="ou=groups,dc=ump,dc=ac,dc=za",
  priority=20,
  enabled=false
)
@FormAuthenticationMechanismDefinition(loginToContinue = @jakarta.security.enterprise.authentication.mechanism.http.LoginToContinue(
  loginPage="/login.xhtml", errorPage="/login.xhtml?error=true"))
public class SecurityConfig {}
