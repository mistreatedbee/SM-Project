package za.ac.ump.sms.lab09.web;
import jakarta.servlet.*;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
@WebServlet("/admin/upload/students")
@MultipartConfig
public class StudentUploadServlet extends HttpServlet {
  @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
    Part file = req.getPart("file");
    int count = 0;
    try (var reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
      String line; boolean headerSkipped=false;
      while ((line = reader.readLine()) != null) {
        if (!headerSkipped) { headerSkipped=true; continue; }
        // TODO: parse and persist (Lab 06/10)
        count++;
      }
    }
    resp.getWriter().println("Imported: " + count);
  }
}
