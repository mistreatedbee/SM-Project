package za.ac.ump.sms.lab13.soap;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
@WebService(serviceName="StudentVerificationService")
public class StudentVerificationEndpoint {
  @WebMethod
  public boolean verifyStudent(@WebParam(name="studentNo") String studentNo){
    // TODO: query DB in Lab 06
    return studentNo != null && !studentNo.isBlank();
  }
}
