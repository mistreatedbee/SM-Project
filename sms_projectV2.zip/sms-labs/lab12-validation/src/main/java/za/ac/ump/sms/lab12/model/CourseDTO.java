package za.ac.ump.sms.lab12.model;
import jakarta.validation.constraints.*;
public class CourseDTO {
  @Pattern(regexp="^[A-Z]{3}\d{3}$") public String courseCode;
  @NotBlank public String title;
  @Min(1) @Max(32) public int credits;
}
