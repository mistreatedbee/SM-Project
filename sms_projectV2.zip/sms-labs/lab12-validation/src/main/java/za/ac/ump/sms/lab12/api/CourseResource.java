package za.ac.ump.sms.lab12.api;
import za.ac.ump.sms.lab12.model.CourseDTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
@Path("/courses")
@Consumes(MediaType.APPLICATION_JSON) @Produces(MediaType.APPLICATION_JSON)
public class CourseResource {
  @POST
  public Response create(@Valid CourseDTO dto){
    return Response.status(Response.Status.CREATED).entity(dto).build();
  }
}
