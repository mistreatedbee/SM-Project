package za.ac.ump.sms.lab07.ws;
import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
@ServerEndpoint("/ws/notifications/{userId}")
public class NotificationSocket {
  private static final Map<String, Session> SESSIONS = new ConcurrentHashMap<>();
  @OnOpen public void onOpen(Session s, @PathParam("userId") String userId){ SESSIONS.put(userId, s); }
  @OnClose public void onClose(Session s, @PathParam("userId") String userId){ SESSIONS.remove(userId); }
  public static void push(String userId, String message){
    var s = SESSIONS.get(userId);
    if (s != null) s.getAsyncRemote().sendText(message);
  }
}
