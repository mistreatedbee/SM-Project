# Jakarta EE School Management System — Starter Labs 

This workspace contains Maven starter projects for each lab (NetBeans + GlassFish 7, JDK 17, MySQL).

This starter project was created and developed by the Module Lecturer, Dr Olalekan Samuel OGUNLEYE

## Quick start
1. Start MySQL, create JDBC pool/resource in GlassFish (`jdbc/smsDS`).
2. In NetBeans: `File > Open Project...` and select the root `sms-labs` (it will load all modules).
3. Right-click any lab module > **Run** to deploy to GlassFish.
4. Use the Postman collection (`postman/SMS-Labs.postman_collection.json`) to test endpoints.

## Modules
- lab01-cdi — CDI utilities (LoggerProducer).
- lab02-rest — JAX-RS app with StudentResource.
- lab03-json — JSON-P/JSON-B diagnostics endpoint.
- lab04-microservices-gateway — REST client gateway.
- lab05-faces — JSF sample page.
- lab06-persistence — JPA setup with `persistence.xml` using `jdbc/smsDS`.
- lab07-websocket — WebSocket notifications endpoint.
- lab08-security — Jakarta Security DB + optional LDAP + FORM login.
- lab09-servlet — CSV upload servlet.
- lab10-ejb — Stateless bean + scheduled job.
- lab11-messaging — JMS MDB consumer skeleton.
- lab12-validation — Bean Validation on REST payloads.
- lab13-soap — SOAP web service endpoint (WSDL at `/StudentVerificationService?wsdl`).

> Context paths are the artifactIds (e.g., `http://localhost:8080/lab02-rest/api/...`).
