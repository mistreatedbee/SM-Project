package za.ac.ump.sms.lab10.jobs;
import jakarta.ejb.Schedule;
import jakarta.ejb.Singleton;
@Singleton
public class NightlyJobs {
  @Schedule(hour="2", persistent=false)
  public void rebuildCaches(){
    // placeholder
  }
}
