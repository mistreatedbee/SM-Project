package za.ac.ump.sms.lab10.service;
import jakarta.ejb.Stateless;
import jakarta.ejb.TransactionAttribute;
import jakarta.ejb.TransactionAttributeType;
@Stateless
public class EnrollmentService {
  @TransactionAttribute(TransactionAttributeType.REQUIRED)
  public void enrollAndNotify(long studentId, long courseId){
    // TODO: persist Enrollment and send JMS message (Lab 11)
  }
}
