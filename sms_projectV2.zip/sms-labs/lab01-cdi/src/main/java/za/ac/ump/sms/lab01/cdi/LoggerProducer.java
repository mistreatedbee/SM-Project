package za.ac.ump.sms.lab01.cdi;
import jakarta.enterprise.inject.Produces;
import jakarta.enterprise.inject.spi.InjectionPoint;
import java.util.logging.Logger;
public class LoggerProducer {
  @Produces
  public Logger produce(InjectionPoint ip){
    return Logger.getLogger(ip.getMember().getDeclaringClass().getName());
  }
}
