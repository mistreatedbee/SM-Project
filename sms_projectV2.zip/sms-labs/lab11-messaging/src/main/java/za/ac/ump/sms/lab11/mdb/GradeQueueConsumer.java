package za.ac.ump.sms.lab11.mdb;
import jakarta.ejb.ActivationConfigProperty;
import jakarta.ejb.MessageDriven;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.JMSException;
@MessageDriven(activationConfig = {
  @ActivationConfigProperty(propertyName="destinationLookup", propertyValue="jms/gradeQueue"),
  @ActivationConfigProperty(propertyName="destinationType", propertyValue="jakarta.jms.Queue")
})
public class GradeQueueConsumer implements MessageListener {
  @Override public void onMessage(Message msg){
    try {
      String payload = msg.getBody(String.class);
      System.out.println("Queue event: " + payload);
    } catch (JMSException e){ e.printStackTrace(); }
  }
}
