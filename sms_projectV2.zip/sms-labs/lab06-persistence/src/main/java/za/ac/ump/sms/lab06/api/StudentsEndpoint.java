package za.ac.ump.sms.lab06.api;
import jakarta.inject.*;
import jakarta.persistence.*;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import java.util.List;
@Path("/students")
@Produces(MediaType.APPLICATION_JSON)
public class StudentsEndpoint {
  @PersistenceContext EntityManager em;
  @GET
  public List<?> list(){
    return em.createQuery("select s from Student s").setMaxResults(10).getResultList();
  }
}
