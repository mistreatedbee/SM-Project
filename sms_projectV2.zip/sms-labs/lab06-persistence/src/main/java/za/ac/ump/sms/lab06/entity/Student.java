package za.ac.ump.sms.lab06.entity;
import jakarta.persistence.*;
@Entity @Table(name="students")
public class Student {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @Column(name="student_no", unique=true, nullable=false) private String studentNo;
  @Column(nullable=false) private String firstName;
  @Column(nullable=false) private String lastName;
  public Long getId(){return id;} public String getStudentNo(){return studentNo;}
  public void setStudentNo(String s){this.studentNo=s;} public String getFirstName(){return firstName;}
  public void setFirstName(String s){this.firstName=s;} public String getLastName(){return lastName;}
  public void setLastName(String s){this.lastName=s;}
}
