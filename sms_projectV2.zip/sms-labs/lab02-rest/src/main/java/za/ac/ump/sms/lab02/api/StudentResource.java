package za.ac.ump.sms.lab02.api;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.logging.Logger;

@Path("/students")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class StudentResource {
  public static class StudentDTO {
    @NotBlank public String firstName;
    @NotBlank public String lastName;
    public String email;
    public String studentNo;
  }
  @Inject Logger log;

  @GET
  public List<StudentDTO> list(){ return java.util.List.of(); }

  @POST
  public Response create(@Valid StudentDTO dto){
    log.info(() -> "Create student called for " + dto.studentNo);
    return Response.status(Response.Status.CREATED).build();
  }
}
